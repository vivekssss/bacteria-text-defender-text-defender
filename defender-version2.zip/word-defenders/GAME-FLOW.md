# 🎮 Word Defender - Game Flow Diagram

## 📊 Complete Game Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    USER OPENS CHROME                         │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│              EXTENSION ICON IN TOOLBAR                       │
│                  (User clicks it)                            │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                   POPUP OPENS                                │
│  ┌────────────────────────────────────────────────┐         │
│  │  🦠 Word Defender                              │         │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │         │
│  │  📊 Statistics:                                │         │
│  │     🏆 High Score: 1250                        │         │
│  │     🎮 Games Played: 15                        │         │
│  │     🎯 Total Kills: 342                        │         │
│  │                                                 │         │
│  │  [    START GAME    ]  ← User clicks          │         │
│  │  [   Reset Stats    ]                          │         │
│  └────────────────────────────────────────────────┘         │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│            MESSAGE SENT TO CONTENT SCRIPT                    │
│              { action: 'startGame' }                         │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                  GAME INITIALIZES                            │
│  • Extract words from webpage                               │
│  • Create canvas overlay                                     │
│  • Initialize game state                                     │
│  • Spawn initial bacteria (3)                               │
│  • Start game loop (60 FPS)                                 │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                   GAME SCREEN                                │
│  ┌────────────────────────────────────────────────────┐     │
│  │  ❤️ Lives: 3  🎯 Score: 0  🔥 Combo: 0  📊 Level: 1│     │
│  ├────────────────────────────────────────────────────┤     │
│  │                                                     │     │
│  │         🦠 "defend"                                │     │
│  │                    🦠 "shoot"                      │     │
│  │    🦠 "type"                                       │     │
│  │                                                     │     │
│  │                                                     │     │
│  ├────────────────────────────────────────────────────┤     │
│  │         [  Type to shoot...  ]                     │     │
│  │         ⚡ 🏹 🚀 💥 ⚪                             │     │
│  └────────────────────────────────────────────────────┘     │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                  GAME LOOP (60 FPS)                          │
│                                                              │
│  ┌──────────────────────────────────────────────┐           │
│  │  1. Update bacteria positions                │           │
│  │  2. Check for letter eating                  │           │
│  │  3. Update projectiles                       │           │
│  │  4. Check collisions                         │           │
│  │  5. Update particles                         │           │
│  │  6. Draw everything                          │           │
│  │  7. Check multiplication timer (5 sec)       │           │
│  │  8. Update UI                                │           │
│  │  9. Check game over condition                │           │
│  └──────────────────────────────────────────────┘           │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
        ┌─────────────┴─────────────┐
        │                           │
        ▼                           ▼
┌──────────────────┐      ┌──────────────────┐
│  USER TYPES "d"  │      │  5 SECONDS PASS  │
└────────┬─────────┘      └────────┬─────────┘
         │                         │
         ▼                         ▼
┌──────────────────┐      ┌──────────────────┐
│ Input: "d"       │      │ BACTERIA SPLITS  │
│ Match: "defend"  │      │ "defend" →       │
└────────┬─────────┘      │ "def" + "end"    │
         │                └────────┬─────────┘
         ▼                         │
┌──────────────────┐               │
│ User types more  │               │
│ "de", "def"...   │               │
└────────┬─────────┘               │
         │                         │
         ▼                         │
┌──────────────────┐               │
│ Complete word!   │               │
│ "defend"         │               │
└────────┬─────────┘               │
         │                         │
         ▼                         │
┌──────────────────┐               │
│ SHOOT PROJECTILE │               │
│      ⚡→🦠       │               │
└────────┬─────────┘               │
         │                         │
         ▼                         │
┌──────────────────┐               │
│ COLLISION!       │               │
│ Bacteria takes   │               │
│ damage           │               │
└────────┬─────────┘               │
         │                         │
         ▼                         │
┌──────────────────┐               │
│ Health = 0?      │               │
│ YES → DESTROY    │               │
└────────┬─────────┘               │
         │                         │
         ▼                         │
┌──────────────────┐               │
│ 💥 EXPLOSION!    │               │
│ +70 points       │               │
│ Combo +1         │               │
└────────┬─────────┘               │
         │                         │
         └─────────┬───────────────┘
                   │
                   ▼
         ┌─────────────────┐
         │  CONTINUE GAME   │
         └─────────┬────────┘
                   │
         ┌─────────┴─────────┐
         │                   │
         ▼                   ▼
┌──────────────┐    ┌──────────────┐
│ Lives > 0?   │    │ Score > 500? │
│ YES → Loop   │    │ YES → Level  │
│ NO → Game    │    │ Up!          │
│ Over         │    └──────────────┘
└──────┬───────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│                    GAME OVER SCREEN                          │
│  ┌────────────────────────────────────────────────────┐     │
│  │                                                     │     │
│  │              GAME OVER                             │     │
│  │                                                     │     │
│  │         Final Score: 1250                          │     │
│  │         Max Combo: 15                              │     │
│  │         Level Reached: 3                           │     │
│  │                                                     │     │
│  │      🏆 NEW HIGH SCORE! 🏆                         │     │
│  │                                                     │     │
│  │         Press ESC to exit                          │     │
│  │                                                     │     │
│  └────────────────────────────────────────────────────┘     │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│              SAVE STATS TO CHROME STORAGE                    │
│  • Update high score (if new record)                        │
│  • Increment games played                                   │
│  • Add to total kills                                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                USER PRESSES ESC                              │
│              Game overlay removed                            │
│              Return to normal browsing                       │
└─────────────────────────────────────────────────────────────┘
```

## 🔄 Detailed Component Interactions

### 1. Extension Lifecycle
```
Chrome Browser
    ↓
Extension Installed
    ↓
Icon in Toolbar
    ↓
User Clicks Icon
    ↓
popup.html loads
    ↓
popup.js executes
    ↓
Displays stats from storage
```

### 2. Game Start Flow
```
User clicks "Start Game"
    ↓
popup.js sends message
    ↓
content.js receives message
    ↓
initGame() called
    ↓
Extract words from page
    ↓
Create game container
    ↓
Create canvas
    ↓
Setup event listeners
    ↓
Spawn bacteria
    ↓
Start game loop
```

### 3. Typing Flow
```
User presses key
    ↓
keydown event
    ↓
Check if letter
    ↓
Add to currentInput
    ↓
Check all bacteria
    ↓
Find matching word
    ↓
Partial match? → Continue
Complete match? → Shoot!
No match? → Reset input
```

### 4. Shooting Flow
```
Complete word typed
    ↓
Create projectile
    ↓
Set target (bacteria)
    ↓
Calculate velocity
    ↓
Add to projectiles array
    ↓
Game loop updates position
    ↓
Check collision each frame
    ↓
Hit? → Damage bacteria
    ↓
Health = 0? → Destroy
    ↓
Award points
    ↓
Increase combo
```

### 5. Bacteria Lifecycle
```
Spawn at edge
    ↓
Move towards center
    ↓
Every frame:
  • Update position
  • Check eating timer
  • Update animations
    ↓
Eating timer expires?
    ↓
Eat letter (Golden Ratio)
    ↓
Word empty? → Lose life
    ↓
5 seconds pass? → Split
    ↓
Hit by projectile? → Take damage
    ↓
Health = 0? → Explode
```

### 6. Scoring Flow
```
Bacteria destroyed
    ↓
Calculate points:
  Word length × 10 × (Combo + 1)
    ↓
Add to score
    ↓
Increase combo
    ↓
Check for level up:
  Score > Level × 500?
    ↓
Level up!
  • Spawn more bacteria
  • Increase difficulty
```

## 🎯 State Management

### Game State Variables
```javascript
gameActive: boolean      // Is game running?
score: number           // Current score
level: number           // Current level
lives: number           // Remaining lives
combo: number           // Current combo
currentInput: string    // What user typed
bacteria: Array         // All bacteria
projectiles: Array      // All projectiles
particles: Array        // All particles
weaponType: string      // Selected weapon
```

### State Transitions
```
IDLE → START_GAME → PLAYING → GAME_OVER → IDLE
                        ↓
                    PAUSED (ESC)
                        ↓
                    PLAYING (Resume)
```

## 📊 Data Flow

### Chrome Storage
```
popup.js ←→ Chrome Storage ←→ content.js
    ↓                              ↓
Read stats                    Save stats
Display UI                    On game over
```

### Message Passing
```
popup.js → chrome.runtime.sendMessage()
              ↓
         Content Script
              ↓
    chrome.runtime.onMessage
              ↓
         initGame()
```

## 🎨 Render Pipeline

### Each Frame (60 FPS)
```
1. Clear canvas (with transparency)
2. Draw grid background
3. Update & draw particles
4. Update & draw projectiles
5. Update & draw bacteria
6. Update UI elements
7. Check game conditions
8. Request next frame
```

### Drawing Order (Back to Front)
```
1. Background gradient
2. Grid lines
3. Particles (oldest first)
4. Projectile trails
5. Projectiles
6. Bacteria tentacles
7. Bacteria bodies
8. Bacteria eyes
9. Words above bacteria
10. Health bars
11. UI overlay (always on top)
```

## ⚡ Performance Considerations

### Optimization Strategies
```
• Limit bacteria count (max 20)
• Clean up dead particles
• Use requestAnimationFrame
• Efficient collision detection
• Canvas state management (save/restore)
• Event delegation
• Throttle resize events
```

### Memory Management
```
Create → Use → Destroy
   ↓       ↓       ↓
Bacteria Alive  Remove from array
Particle Fade   Filter dead particles
Projectile Hit  Splice from array
```

---

**This flow diagram shows the complete lifecycle of the Word Defender game from installation to gameplay! 🎮**
